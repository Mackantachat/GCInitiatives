﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PTT_GC_API.Models.ResourceNeeded
{
    public class Waste
    {
        [Key]
        public int Id { get; set; }
        public int? ResourceNeededId { get; set; }
        public string Topic { get; set; }
        public string Unit { get; set; }
        public string Remark { get; set; }
    }
}
